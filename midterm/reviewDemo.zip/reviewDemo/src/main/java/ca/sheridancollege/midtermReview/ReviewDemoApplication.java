package ca.sheridancollege.midtermReview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewDemoApplication.class, args);
	}

}
