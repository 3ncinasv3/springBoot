package ca.sheridancollege.midtermReview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
