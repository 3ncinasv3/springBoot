package dev.encinasv.restApplicationProj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApplicationProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
