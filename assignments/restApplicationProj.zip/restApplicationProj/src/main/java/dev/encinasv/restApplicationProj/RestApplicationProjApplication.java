package dev.encinasv.restApplicationProj;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApplicationProjApplication {
	public static void main(String[] args) {
		SpringApplication.run(RestApplicationProjApplication.class, args);
	}

}
