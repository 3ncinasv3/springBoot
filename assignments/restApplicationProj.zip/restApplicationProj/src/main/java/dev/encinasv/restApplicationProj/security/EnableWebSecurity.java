package dev.encinasv.restApplicationProj.security;
public @interface EnableWebSecurity {

}

