package ca.sheridan.lec91_securityLoginLogout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lec91SecurityLoginLogoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lec91SecurityLoginLogoutApplication.class, args);
	}

}
