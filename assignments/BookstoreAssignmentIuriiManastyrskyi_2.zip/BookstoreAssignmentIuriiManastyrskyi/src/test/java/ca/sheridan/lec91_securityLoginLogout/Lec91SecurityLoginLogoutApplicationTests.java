package ca.sheridan.lec91_securityLoginLogout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lec91SecurityLoginLogoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
