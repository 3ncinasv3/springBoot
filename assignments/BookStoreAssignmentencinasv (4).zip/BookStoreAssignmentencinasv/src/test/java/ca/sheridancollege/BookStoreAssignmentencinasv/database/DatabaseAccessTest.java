package ca.sheridancollege.BookStoreAssignmentencinasv.database;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DatabaseAccessTest {

    @Test
    void getBooks() {
    }

    @Test
    void getBooksSize() {
    }

    @Test
    void getBookByISBN() {
    }

    @Test
    void getCustomers() {
    }

    @Test
    void getCustomerListSize() {
    }

    @Test
    void getCustomerEmailByID() {
    }

    @Test
    void getCustomerPassByID() {
    }

    @Test
    void registerCustomer() {
    }
}